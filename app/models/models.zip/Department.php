<?php

class Department extends \Eloquent {
	protected $fillable = [];
	protected $table = 'departments';
}