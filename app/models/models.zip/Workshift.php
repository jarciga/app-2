<?php

class Workshift extends \Eloquent {
	protected $fillable = [];
}