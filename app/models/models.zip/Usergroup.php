<?php

class Usergroup extends \Eloquent {
	protected $fillable = [];
	protected $table = 'users_groups';	
}