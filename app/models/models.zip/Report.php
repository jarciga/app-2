<?php

class Report extends \Eloquent {
	protected $fillable = [];
}