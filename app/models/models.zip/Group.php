<?php

class Group extends \Eloquent {
	protected $fillable = [];
}