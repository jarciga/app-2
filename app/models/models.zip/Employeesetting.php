<?php

class Employeesetting extends \Eloquent {
	protected $fillable = [];
	protected $table = 'employee_setting';	
}