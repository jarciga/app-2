<?php

class Permission extends \Eloquent {
	protected $fillable = [];
}