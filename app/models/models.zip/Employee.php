<?php

class Employee extends \Eloquent {
	protected $fillable = [];
}