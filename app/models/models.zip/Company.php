<?php

class Company extends \Eloquent {
	protected $fillable = [];
	protected $table = 'companies';
}