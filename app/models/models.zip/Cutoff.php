<?php

class Cutoff extends \Eloquent {
	protected $fillable = [];
	protected $table = 'cutoffs';
}