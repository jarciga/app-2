<?php

class Searchtimesheet extends \Eloquent {
	protected $fillable = [];
}