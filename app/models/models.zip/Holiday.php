<?php

class Holiday extends \Eloquent {
	protected $fillable = [];
	protected $table = 'holiday';
}