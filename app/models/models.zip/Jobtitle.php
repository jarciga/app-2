<?php

class Jobtitle extends \Eloquent {
	protected $fillable = [];
	protected $table = 'job_title';
}