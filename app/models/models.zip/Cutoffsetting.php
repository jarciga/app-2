<?php

class Cutoffsetting extends \Eloquent {
	protected $fillable = [];
    protected $table = 'cutoff_setting';	
}