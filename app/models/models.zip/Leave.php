<?php

class Leave extends \Eloquent {
	protected $fillable = [];
	protected $table = 'leave';	
}