<?php

class Leavesetting extends \Eloquent {
	protected $fillable = [];
}