<div class="panel panel-default">
  <div class="panel-heading">
    
    <h3 class="panel-title">
      @if("admin.schedules.show.schedule.uploader" === $resourceId)
        Add New User      
      @elseif("admin.schedules.show.schedule.edit" === $resourceId)
        Edit User
      @endif      
    </h3>
    

  </div>  
  <div class="panel-body">

  @if ($errors->has())
  <div class="alert alert-danger" role="alert">
      <ul style="list-style:none; margin:0; padding:0;">
          @foreach ($errors->all() as $error)
              <li style="list-style-type:none; margin:0; padding:0;"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> <span class="sr-only">Error:</span>{{ $error }}</li>
          @endforeach
      </ul>
  </div>

  @elseif ( !empty($message) )
      <div class="alert alert-success" role="alert">
          <ul style="list-style:none; margin:0; padding:0;">
              
              <li style="list-style-type:none; margin:0; padding:0;"><span class="glyphicon" aria-hidden="true"></span> <span class="sr-only">Success:</span>{{ $message }}</li>

          </ul>
      </div>
  @endif
  
  @if("admin.schedules.show.schedule.uploader" === $resourceId)  
  
    
    {{-- Form::open(array('url' => '/admin/schedule/new', 'id' => 'formScheduleNew', 'class' => 'form-horizontal')) --}}                  
    
    {{ Form::close() }}   

                <h4>Upload New Schedule</h4>
                {{ Form::open(array('url'=>'/admin/schedule/uploaded','files'=>true, 'method'=>'POST')) }}

                <div class="form-group">                    
                {{-- Form::label('file','Upload New Schedule',array('id'=> '', 'class' => 'col-sm-3 control-label')) --}} 
                {{ Form::file('file','',array('id' => '', 'class' => 'form-control')) }}    
                </div>

                <div class="form-group">
                {{ Form::submit('Save', array('class' => '', 'class' => 'btn btn-primary')) }}
                {{ Form::reset('Reset', array('class' => '', 'class' => 'btn btn-primary')) }}
                </div>

                {{ Form::close() }}

                <hr>
                <h4 style="font-family: "Times New Roman", Times, serif;">Update Schedule</h4>

                {{ Form::open(array('url' => '/admin/schedule/search')) }}

                  {{ Form::label('Employee Number', 'Employee Number'); }}
                  {{ Form::text('employee_number', ''); }}

                  {{ Form::label('Date From', 'Date From') }}
                  {{ Form::text('schedule_date_from', '', array('class' => 'datepicker')) }}
                  {{ Form::label('Date To', 'Date to') }}
                  {{ Form::text('schedule_date_to', '', array('class' => 'datepicker')) }}

                  {{ Form::submit('Search', array('class' => '', 'class' => 'btn btn-primary')) }}                

                {{ Form::close() }}


                <?php if( !empty($uploadedSchedules) ) { ?>

                  
                {{ Form::open(array('route' => 'process.schedule.edit', 'id' => '', 'class' => 'form-horizontal')) }}                          

                <div class="form-group pull-right">
                    <div class="col-md-12">
                    {{ Form::submit('Update', array('class' => '', 'class' => 'btn btn-primary')) }}          
                    </div>
                </div>                 
                            
                <table class="table table-striped table-hover table-list display" cellspacing="0" width="100%">

                        <thead>
                            <tr>
                                <th>Schedule Date</th>
                                <th class="hide hidden">Shift</th>                
                                <th>Rest day</th>
                                <!--th>Hours per day</th-->                
                                <th>Start time</th>
                                <th>Start Date</th>
                                <th>End time</th>  
                                <th>End Date</th>                                              
                            </tr>
                        </thead>

                        <tbody>            
                              
                        <?php

                            foreach($uploadedSchedules as $key => $uploadedSchedule) {

                              list($startDate, $startTime) = explode(' ', $uploadedSchedule->start_time);
                              list($endDate, $endTime) = explode(' ', $uploadedSchedule->end_time);

                              list($starttimehh, $starttimemm) = explode(':', trim($startTime));
                              list($endtimehh, $endtimemm) = explode(':', trim($endTime));                            

                        ?>

                            <tr>
                                <td>                                  
                                  <?php echo Form::hidden('schedule['.$key.'][uploadedScheduleId]',  $uploadedSchedule->id); ?>
                                  <?php echo Form::hidden('schedule['.$key.'][employeeId]',  $uploadedSchedule->employee_id); ?>
                                  <strong><?php echo $uploadedSchedule->schedule_date; ?></strong>
                                  <?php //echo Form::text('schedule['.$key.'][scheduledate]', $uploadedSchedule->schedule_date, array('readonly' => 'readonly')); ?>
                                </td>
                                <!--td>Shift</td-->                
                                <td class="hide hidden"><?php echo Form::select('schedule['.$key.'][shift]', array(1 => 1, 2 => 2), $uploadedSchedule->shift, array()); ?></td>                                             
                                <td><?php echo Form::select('schedule['.$key.'][restday]', array(0 => 'No', 1 => 'Yes'), $uploadedSchedule->rest_day, array()); ?></td>                
                                <!--td>Hours per day</td-->                
                                <td>
                                <?php
                                    echo Form::select(
                                             'schedule['.$key.'][starttimehh]',
                                             array('00' => '00', '01' => '01', '02' => '02', '03' => '03', '04' => '04', '05' => '05', '06' => '06', '07' => '07', '08' => '08', '09' => '09', 10 => '10', 11 => '11', 12 => '12',
                                                   13 => '13', 14 => '14', 15 => '15', 16 => '16', 17 => '17', 18 => '18', 19 => '19', 20 => '20', 21 => '21', 22 => '22', 23 => '23', 24 => '24'
                                                  ),
                                             $starttimehh,
                                             array()
                                         );
                                ?>
                                
                                <?php
                                    echo Form::select(
                                             'schedule['.$key.'][starttimemm]',
                                             array('00' => '00', '01' => '01', '02' => '02', '03' => '03', '04' => '04', '05' => '05', '06' => '06', '07' => '07', '08' => '08', '09' => '09', 10 => '10',
                                                   11 => '11', 12 => '12', 13 => '13', 14 => '14', 15 => '15', 16 => '16', 17 => '17', 18 => '18', 19 => '19',
                                                   20 => '20', 21 => '21', 22 => '22', 23 => '23', 24 => '24', 25 => '25', 26 => '26', 27 => '27', 28 => '28', 29 => '29',
                                                   30 => '30', 31 => '31', 32 => '32', 33 => '33', 34 => '34', 35 => '35', 36 => '36', 37 => '37', 38 => '38', 39 => '39',
                                                   40 => '40', 41 => '41', 42 => '42', 43 => '43', 44 => '44', 45 => '45', 46 => '46', 47 => '47', 48 => '48', 49 => '49',
                                                   50 => '50', 51 => '51', 52 => '52', 53 => '53', 54 => '54', 55 => '55', 56 => '56', 57 => '57', 58 => '58', 59 => '59',
                                                   60 => '60'),
                                             $starttimemm,
                                             array()
                                         );
                                ?>
                                </td>
                                <td>                                
                                  <?php 
                                  //echo Form::hidden('schedule['.$key.'][startdate]', $startDate);
                                  echo Form::text('schedule['.$key.'][startdate]', $startDate, array('class' => 'datepicker'));
                                  ?>
                                  
                                  <strong><?php //echo $startDate; ?></strong>
                                </td>                             
                                <td>
                                <?php
                                    echo Form::select(
                                             'schedule['.$key.'][endtimehh]',
                                             array('00' => '00', '01' => '01', '02' => '02', '03' => '03', '04' => '04', '05' => '05', '06' => '06', '07' => '07', '08' => '08', '09' => '09', 10 => '10', 11 => '11', 12 => '12',
                                                   13 => '13', 14 => '14', 15 => '15', 16 => '16', 17 => '17', 18 => '18', 19 => '19', 20 => '20', 21 => '21', 22 => '22', 23 => '23', 24 => '24'
                                                  ),
                                             $endtimehh,
                                             array()
                                         );
                                ?>
                                
                                <?php
                                    echo Form::select(
                                             'schedule['.$key.'][endtimemm]',
                                             array('00' => '00', '01' => '01', '02' => '02', '03' => '03', '04' => '04', '05' => '05', '06' => '06', '07' => '07', '08' => '08', '09' => '09', 10 => '10',
                                                   11 => '11', 12 => '12', 13 => '13', 14 => '14', 15 => '15', 16 => '16', 17 => '17', 18 => '18', 19 => '19',
                                                   20 => '20', 21 => '21', 22 => '22', 23 => '23', 24 => '24', 25 => '25', 26 => '26', 27 => '27', 28 => '28', 29 => '29',
                                                   30 => '30', 31 => '31', 32 => '32', 33 => '33', 34 => '34', 35 => '35', 36 => '36', 37 => '37', 38 => '38', 39 => '39',
                                                   40 => '40', 41 => '41', 42 => '42', 43 => '43', 44 => '44', 45 => '45', 46 => '46', 47 => '47', 48 => '48', 49 => '49',
                                                   50 => '50', 51 => '51', 52 => '52', 53 => '53', 54 => '54', 55 => '55', 56 => '56', 57 => '57', 58 => '58', 59 => '59',
                                                   60 => '60'),
                                             $endtimemm,
                                             array()
                                         );
                                ?>
                                </td>                                                
                                <td>                                                                  
                                  <?php 
                                  //echo Form::hidden('schedule['.$key.'][enddate]', $endDate);
                                  echo Form::text('schedule['.$key.'][enddate]', $endDate, array('class' => 'datepicker'));
                                  ?>
                                  
                                  <strong><?php //echo $endDate; ?></strong>                                  
                                </td>                             
                            </tr>

                            <?php } ?>                            
                      
                        </tbody>

                    </table>

                    <div class="form-group pull-right">
                        <div class="col-md-12">
                        {{ Form::submit('Update', array('class' => '', 'class' => 'btn btn-primary')) }}          
                        </div>
                    </div> 

                    {{ Form::close() }}
                            

                <?php } ?>              
    
  @elseif("admin.schedules.show.schedule.edit" === $resourceId)

 

  @endif  

  </div>
</div>