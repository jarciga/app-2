
<div class="row">
  <div class="col-md-12"> 
    <h3>Job Titles</h3>
    @include('jobtitles.widget')    
  </div>

</div>