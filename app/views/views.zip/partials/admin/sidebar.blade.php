<aside class="sidebar">
  <nav class="sidebar-nav">
    <ul id="menu">
      <li>
        <a href="{{ url('/admin') }}">
          <span class="sidebar-nav-item-icon fa fa-tachometer fa-lg"></span>                      
          <span class="sidebar-nav-item">Dashboard</span>                      
        </a>
        
      </li>
      <li>
        <a href="#">
          <span class="sidebar-nav-item-icon fa fa-users fa-lg"></span>                      
          <span class="sidebar-nav-item">Employees</span>                      
        </a>

        <ul class="submenu-1 collapse">
            <li><a href="{{ url('/admin/user/lists') }}">All Employees</a></li>
            <li><a href="{{ url('/admin/user/new') }}">Add New Employee</a></li>
        </ul>                    
        
      </li>                  
      <li>
          <a href="{{ url('/admin/scheduling') }}">
          <span class="sidebar-nav-item-icon fa fa-calendar fa-lg"></span>
          <span class="sidebar-nav-item">Schedule</span>
          </a>
          <ul class="submenu-1 collapse">
            <li><a href="{{ url('/admin/holiday/lists') }}">All Holidays</a></li>
            <li><a href="{{ url('/admin/holiday/new') }}">Add New Holiday</a></li>

            <li><a href="{{ url('/admin/schedule/uploader') }}">Upload Schedule</a></li>
          </ul>          
      </li>                  
      <li>
          <a href="#">
          <span class="sidebar-nav-item-icon fa fa-clock-o fa-lg"></span>
          <span class="sidebar-nav-item">TimeClock</span>
          </a>
          <!--ul class="submenu-1 collapse">
              <li><a href="{{ url('/admin/overtime/lists') }}">All Overtimes</a></li>                            
          </ul-->
      </li>
      <li>
          <a href="#">
          <span class="sidebar-nav-item-icon fa fa-folder-o fa-lg"></span>
          <span class="sidebar-nav-item">Requests</span>
          </a>
          <ul class="submenu-1">
              <li><a href="{{ url('/admin/overtime/lists') }}">All Overtimes</a></li>
              <li><a href="{{ url('/admin/leave/lists') }}">All Leaves</a></li>              
          </ul>
      </li>
      <li>
          <a href="#">
          <span class="sidebar-nav-item-icon fa fa-bar-chart fa-lg"></span>
          <span class="sidebar-nav-item">Reports</span>
          </a>
          <ul class="submenu-1">
              <li><a href="{{ url('/summary/report/employee') }}">My Summary Report</a></li>
              <li><a href="{{ url('/summary/reports/employees?page=1') }}">Employees Summary Report</a></li>              
          </ul>
      </li>

      <li>
          <a href="">
          <span class="sidebar-nav-item-icon fa fa-building fa-lg"></span>
          <span class="sidebar-nav-item">Payroll</span>
          </a>
          <ul class="submenu-1 collapse">
            <li><a href="{{ url('/admin/payroll/reminder/lists') }}">Payroll Reminder</a></li>
            <li><a href="{{ url('/admin/payroll/new') }}">Process Payroll</a></li>
          </ul>                     
      </li> 

      <li>
          <a href="">
          <span class="sidebar-nav-item-icon fa fa-building fa-lg"></span>
          <span class="sidebar-nav-item">Company</span>
          </a>
          <ul class="submenu-1 collapse">
            <li><a href="{{ url('/admin/company/lists') }}">All Companies</a></li>
            <li><a href="{{ url('/admin/company/new') }}">Add New Company</a></li>

            <li><a href="{{ url('/admin/department/lists') }}">All Departments</a></li>
            <li><a href="{{ url('/admin/department/new') }}">Add New Department</a></li>

            <li><a href="{{ url('/admin/jobtitle/lists') }}">All Job Titles</a></li>
            <li><a href="{{ url('/admin/jobtitle/new') }}">Add New Job Title</a></li>
          </ul>            
      </li>                  

      <li class="hide hidden">
          <a href="#">
          <span class="sidebar-nav-item-icon fa fa-cogs fa-lg"></span>
          <span class="sidebar-nav-item">Admin</span>
          </a>
      </li>                                                                        
      <li>
          <a href="#">
          <span class="sidebar-nav-item-icon fa fa-cogs fa-lg"></span>
          <span class="sidebar-nav-item">Settings</span>
          </a>
          <!--ul class="submenu-1 collapse hide hidden">
              <li><a href="#">item 0.1</a></li>
          </ul-->
      </li>                                                                                          
    </ul>
  </nav>

</aside>   