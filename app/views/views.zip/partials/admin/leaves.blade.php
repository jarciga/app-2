
<div class="row">
  <div class="col-md-12"> 
    <h3>Leaves</h3>
    @include('leaves.widget')    
  </div>

</div>