
<div class="row">
  <div class="col-md-12"> 
    <h3>Departments</h3>
    @include('departments.widget')    
  </div>

</div>