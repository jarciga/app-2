
<div class="row">
  <div class="col-md-12"> 
    <h3>Holidays</h3>
    @include('holidays.widget')    
  </div>

</div>