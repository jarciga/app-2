
<div class="row">
  <div class="col-md-12"> 
    <h3>Employees</h3>
    @include('employees.widget')    
  </div>

</div>