
<div class="row">
  <div class="col-md-12"> 
    <h3>Schedules</h3>
    @include('schedules.widget')    
  </div>

</div>