
<div class="row">
  <div class="col-md-12"> 
    
    <h3>Dashboard</h3>
    
    <div class="col-md-6">
    @include('employees.dashboard') 
    </div>   

    <div class="col-md-6">
    @include('leaves.dashboard')
    </div>

    <div class="col-md-6">
    @include('absences.widget')
    </div>

    <div class="col-md-6">
    @include('overtimes.dashboard')
    </div>

  </div>

</div>