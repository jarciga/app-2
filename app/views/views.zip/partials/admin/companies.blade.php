
<div class="row">
  <div class="col-md-12"> 
    <h3>Companies</h3>
    @include('companies.widget')    
  </div>

</div>