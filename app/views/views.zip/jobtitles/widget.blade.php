<div class="panel panel-default">
  <div class="panel-heading">
    
    <h3 class="panel-title">
      @if("admin.jobtitles.show.jobtitle.new" === $resourceId)
        Add New User      
      @elseif("admin.jobtitles.show.jobtitle.edit" === $resourceId)
        Edit User
      @endif      
    </h3>
    

  </div>  
  <div class="panel-body">

  @if ($errors->has())
  <div class="alert alert-danger" role="alert">
      <ul style="list-style:none; margin:0; padding:0;">
          @foreach ($errors->all() as $error)
              <li style="list-style-type:none; margin:0; padding:0;"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> <span class="sr-only">Error:</span>{{ $error }}</li>
          @endforeach
      </ul>
  </div>

  @elseif ( !empty($message) )
      <div class="alert alert-success" role="alert">
          <ul style="list-style:none; margin:0; padding:0;">
              
              <li style="list-style-type:none; margin:0; padding:0;"><span class="glyphicon" aria-hidden="true"></span> <span class="sr-only">Success:</span>{{ $message }}</li>

          </ul>
      </div>
  @endif
  
  @if("admin.jobtitles.show.jobtitle.new" === $resourceId)  
  
    {{ Form::open(array('url' => '/admin/jobtitle/new', 'id' => '', 'class' => 'form-inline')) }}                
   
    <div class="form-group">
      {{ Form::label('Job Title Name', 'Job Title Name', array('class' => 'sr-only')) }}           
      {{ Form::text('job_title_name', '', array('id' => '', 'class' => 'form-control', 'placeholder' => 'Job Title Name')) }}
    </div>            
      {{ Form::submit('Create Job Title', array('class' => '', 'class' => 'btn btn-custom-default')) }}
    </div>            
    
    {{ Form::close() }}     
    
  @elseif("admin.jobtitles.show.jobtitle.edit" === $resourceId)

    {{ Form::open(array('url' => '/admin/jobtitle/'.$jobTitleEditId.'/edit', 'id' => '', 'class' => 'form-inline')) }}              
    {{ Form::hidden('Department_id', $jobTitleEditId); }}
    <div class="form-group">
      {{ Form::label('Job Title Name', 'Job Title Name', array('class' => 'sr-only')) }}           
      {{ Form::text('job_title_name', $jobTitleArr->name, array('id' => '', 'class' => 'form-control', 'placeholder' => 'Job Title Name')) }}
    </div>            
      {{ Form::submit('Update Job Title', array('class' => '', 'class' => 'btn btn-custom-default')) }}
    </div>            
    
    {{ Form::close() }} 


  @endif


  </div>
</div>