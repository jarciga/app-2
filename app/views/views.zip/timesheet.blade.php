{{-- Child Template --}}
@extends('index')

@section('head')
	@parent
@stop

@section('body')    
    <p>Backoffice Template2</p>
@stop

@section('foot')
	@parent    
@stop